package co.bootjava.palette.cart.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.bootjava.palette.cart.CartVO;
import co.bootjava.palette.common.Command;

public class AddCart implements Command {

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("addCart넘어옴");
		String productNumber = request.getParameter("productNumber");
		String productPrice = request.getParameter("productPrice");
		String imsiUserId = "user1";
		CartVO cart = new CartVO("", productNumber, "", productPrice, imsiUserId);
		return null;
	}

}
