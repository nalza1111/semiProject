package co.bootjava.palette.cart.mapper;

import java.util.List;

import co.bootjava.palette.cart.CartVO;

public interface CartServiceMapper {
	List<CartVO> cartSelectList();
	CartVO cartSelect(CartVO vo);
	int cartInsert(CartVO vo);
	int cartDelete(CartVO vo);
	int cartUpdate(CartVO vo);
}
